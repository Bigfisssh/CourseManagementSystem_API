const Course = require("../models/course");

//this is the create function/method
exports.createCourse = async (req, res) => {
  try {
    //advanced declarations
    const { course, description, modules, duration, availability } = req.body;

    //file storage declared manually and specifies where images should be directed to and saved.
    const imageUrl = "http://localhost:3300/images/" + req.file.filename;

    if(!req.body){
      res.status(401).send({ message: 'cannot upload without info!' })
      return;
    }

    //this the class where we call in the declarations.
    const courseInfo = new Course({
      course,
      description,
      modules,
      duration,
      availability,
      imageUrl,
    });

    //object name.save() - using express functionality
    const savedCourse = await courseInfo.save();
    res.status(201).json(savedCourse);
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
};

exports.getAllCourses = async (_req, res) => {
  try {
    //.find() - finds all courses on the database
    const courses = await Course.find();
    res.status(200).json(courses);
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
};

//get coutrse by id number
exports.getCourseById = async (req, res) => {
  const id = req.params.id;

  try {
    const courses = await Course.findById(id);
    if (!courses) {
      res.status(404).json("cannot find course! Maybe it doesn't exist");
      return;
    }

    res.status(200).json(courses);
  } catch (error) {
    res.status(404).json({ error: error.message });
    return;
  }
};

exports.updateCourseBytId = async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body;
    await Course.findByIdAndUpdate(id, body);

    res.status(201).json("Changes made successfully");
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
};

exports.deleteCourseById = async (req, res) => {
  try {
    const id = req.params.id;
    await Course.findByIdAndRemove(id);
    res.status(201).json("Deleted successfully!");
  } catch (error) {
    res.status(404).json({ error: "couldnt delete" });
  }
};

exports.deleteAllCourses = async (req, res) => {
  try {
    const body = req.body;
    await Course.deleteMany({ }, req.body);
    res.status(201).json("Removed all courses!");
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
};
